def nilai(a):
    if a >= 75:
        print("Tuntas") 
    else:
        print("REMED")

nilai(90)
nilai(75)
nilai(70)